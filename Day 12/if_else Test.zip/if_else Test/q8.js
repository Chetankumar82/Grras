// Write a JS program to input week number and print weekday

let week_num = 5;


if(week_num == 1) {
    console.log("Sunday")
} else if(week_num == 2) {
    console.log("Monday")
} else if(week_num == 3) {
    console.log("Tuesday")
} else if(week_num == 4) {
    console.log("Wednesday")
} else if(week_num == 5) {
    console.log("Thursday")
} else if(week_num == 6) {
    console.log("Friday")
} else if(week_num == 7) {
    console.log("Satday")
} else {
    console.log("Invalid")
}