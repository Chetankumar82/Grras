let a = 10;
let b= 5;
let c= 6;

if (a + b > c && a + c > b && b + c > a) {
    console.log("The triangle is valid.") ;
} else {
    console.log("The triangle is not valid.") ;
}