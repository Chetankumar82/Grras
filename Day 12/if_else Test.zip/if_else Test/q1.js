let num = 10;

if(num==0){
    console.log("number is equal to zero");
}else if(num>0){
    console.log("num is positive");
}else{
    console.log("num is negative");
}