// Write a JS program to check whether a number is divisible by 5 and 11 or not.

let num = 50;
if(num%5==0){
    console.log("number is divisible by 5");
}else if(num%11==0){
    console.log("number is divisible by 11")
} else{
    console.log("number is neither divisible by 5 nor 11")
}
